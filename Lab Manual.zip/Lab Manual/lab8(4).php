<?php 
$a1 = Array('0' => Array('0' => 1,'1' => 2),'1' => Array('0' => 4,'1' => 5));


$a2 = Array('0' => Array('0' => 6,'1' => 7),'1' => Array('0' => 8,'1' => 9));

$sumArray = array();

$result = array();
for($i=0; $i<=1; $i++) {
    for($j=0; $j<=1; $j++) {
        $result[$i][$j] = $a1[$i][$j] + $a2[$i][$j];
    }
}
echo "<pre/>";print_r($result);
?>