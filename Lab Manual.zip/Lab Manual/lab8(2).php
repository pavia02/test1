<?php

$categories = array(
    'item_name' => array('A', 'B', 'C','D'),
    'item_price' => array('70000', '60000', '50000', '40000')
);

$out = array();
foreach($categories as $key => $a){
    foreach($a as $k => $v){
        $out[$k][$key] = $v;
    }
}
echo '<pre>';
print_r($categories);
print_r($out);
echo '</pre>';
?>