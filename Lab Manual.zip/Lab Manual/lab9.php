<?php
$finalList=array();
$words="Mississippi Alabama Texas Massachusetts Kansas";
$EndsWith=['xas'];
$words = explode(' ', $words);
foreach($words as $word) {
    foreach($EndsWith as $end) {
        if(substr($word, -strlen($end)) === $end) {
             echo "Word ending with xas:".$word."<br/>";
             $finalList[0]=$word;
        }
    }
}


// Second Program
$states="Mississippi Alabama Texas Massachusetts Kansas";

function startsWith($haystack, $needle)
{
     $length = strlen($needle);
     return (substr($haystack, 0, $length) === $needle);
}

function endsWith($haystack, $needle)
{
    $length = strlen($needle);

    return $length === 0 || 
    (substr($haystack, -$length) === $needle);
}
$regex = '~(\w+)~';
if (preg_match_all($regex, $states, $matches, PREG_PATTERN_ORDER)) {
   foreach ($matches[1] as $stateList) {
   		
      if(startsWith($stateList,'K')||startsWith($stateList,'A')||startsWith($stateList,'k')||startsWith($stateList,'a'))
      {
      		echo "State with k and s:".$stateList .'<br/>';
      		$finalList[1]=$stateList;
      	}
      }
      
   }

//Third Program


if (preg_match_all($regex, $states, $matches1, PREG_PATTERN_ORDER)) {
   foreach ($matches1[1] as $stateList1) {
   		
      if(startsWith($stateList1,'M')&&endsWith($stateList1,'s'))
      {
      		echo "State with M and s:".$stateList1 .'<br/>';
      		$finalList[2]=$stateList1;
      	}
      }
     
   }


//fourth program
if (preg_match_all($regex, $states, $matches2, PREG_PATTERN_ORDER)) {
   foreach ($matches2[1] as $stateList2) {
   		
      if(endsWith($stateList2,'a'))
      {
      		echo "State with end a:".$stateList2 .'<br/>';
      		$finalList[3]=$stateList2;
      	}
      }
     
   }

for($i=0;$i<4;$i++)
{
	echo $finalList[$i];
}

?>